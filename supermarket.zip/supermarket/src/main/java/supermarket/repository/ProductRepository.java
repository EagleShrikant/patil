package supermarket.repository;

import org.springframework.data.repository.CrudRepository;

import supermarket.dto.Product;

public interface ProductRepository extends CrudRepository<Product, Integer>{

}