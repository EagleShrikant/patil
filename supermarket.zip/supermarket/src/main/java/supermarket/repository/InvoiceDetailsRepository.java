package supermarket.repository;

import org.springframework.data.repository.CrudRepository;

import supermarket.dto.InvoiceDetails;

public interface InvoiceDetailsRepository extends CrudRepository<InvoiceDetails, Integer> {

}
