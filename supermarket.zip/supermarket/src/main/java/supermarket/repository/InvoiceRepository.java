package supermarket.repository;

import org.springframework.data.repository.CrudRepository;

import supermarket.dto.Invoice;

public interface InvoiceRepository extends CrudRepository<Invoice, Integer> {

}
