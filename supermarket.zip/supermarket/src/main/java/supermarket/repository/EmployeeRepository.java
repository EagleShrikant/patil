package supermarket.repository;

import org.springframework.data.repository.CrudRepository;

import supermarket.dto.Employee;

public interface EmployeeRepository extends CrudRepository<Employee, Integer> {

}
