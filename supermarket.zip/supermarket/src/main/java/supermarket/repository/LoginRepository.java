package supermarket.repository;

import org.springframework.data.repository.CrudRepository;

import supermarket.dto.Login;

public interface LoginRepository extends CrudRepository<Login, Integer>{

}
