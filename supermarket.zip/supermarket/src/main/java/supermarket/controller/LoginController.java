package supermarket.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import supermarket.dto.Login;
import supermarket.exception.SuperMarketException;
import supermarket.service.LoginService;

@RestController
@RequestMapping("/v1/supermarket")
public class LoginController {
	
	@Autowired
	LoginService loginService;
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@GetMapping(path = "/login" , produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<List<Login>> getLogins () throws SuperMarketException {
		return ResponseEntity.ok(loginService.getLogins());
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@PostMapping(path = "/login" , produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<Login> createLogin (@Valid @RequestBody Login login) throws SuperMarketException {
		return ResponseEntity.ok(loginService.createLogin(login));
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@PutMapping(path = "/login" , produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<Login> updateLogin (@Valid @RequestBody Login login) throws SuperMarketException {
		return ResponseEntity.ok(loginService.updateLogin(login));
	}
}
