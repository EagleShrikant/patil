package supermarket.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import supermarket.dto.Invoice;
import supermarket.exception.SuperMarketException;
import supermarket.service.InvoiceService;

@RestController
@RequestMapping("/v1/supermarket")
public class InvoiceController {
	@Autowired
	InvoiceService invoiceService;
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@GetMapping(path = "/invoice" , produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<List<Invoice>> getInvoice () throws SuperMarketException {
		return ResponseEntity.ok(invoiceService.getInvoices());
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@PostMapping(path = "/invoice" , produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<Invoice> createInvoice (@Valid @RequestBody Invoice invoice) throws SuperMarketException {
		return ResponseEntity.ok(invoiceService.createInvoice(invoice));
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@PutMapping(path = "/invoice" , produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<Invoice> updateInvoice (@Valid @RequestBody Invoice invoice) throws SuperMarketException {
		return ResponseEntity.ok(invoiceService.updateInvoice(invoice));
	}
}
