package supermarket.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import supermarket.dto.Product;
import supermarket.exception.SuperMarketException;
import supermarket.service.ProductService;

@RestController
@RequestMapping("/v1/supermarket")
public class ProductContoroller {

	@Autowired
	ProductService productService;
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@GetMapping(path = "/product" , produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<List<Product>> getProduct () throws SuperMarketException {
		return ResponseEntity.ok(productService.getProducts());
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@PostMapping(path = "/product" , produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<Product> createProduct (@Valid @RequestBody Product product) throws SuperMarketException {
		return ResponseEntity.ok(productService.createProduct(product));
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@PutMapping(path = "/product" , produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<Product> updateProduct (@Valid @RequestBody Product product) throws SuperMarketException {
		return ResponseEntity.ok(productService.updateProduct(product));
	}
}
