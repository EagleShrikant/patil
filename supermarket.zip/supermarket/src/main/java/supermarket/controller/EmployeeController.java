package supermarket.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import supermarket.dto.Employee;
import supermarket.exception.SuperMarketException;
import supermarket.service.EmployeeService;

@RestController
@RequestMapping("/v1/supermarket")
public class EmployeeController {
	
	@Autowired
	EmployeeService employeeService;
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@GetMapping(path = "/employee" , produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<List<Employee>> getEmloyees () throws SuperMarketException {
		return ResponseEntity.ok(employeeService.getEmployees());
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@PostMapping(path = "/employee" , produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<Employee> createEmloyee (@Valid @RequestBody Employee employee) throws SuperMarketException {
		return ResponseEntity.ok(employeeService.createEmployee(employee));
	}
	
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	@PutMapping(path = "/employee" , produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<Employee> updateEmloyee (@Valid @RequestBody Employee employee) throws SuperMarketException {
		return ResponseEntity.ok(employeeService.updateEmployee(employee));
	}

}
