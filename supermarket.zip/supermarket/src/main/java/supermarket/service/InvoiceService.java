package supermarket.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import supermarket.dto.Invoice;
import supermarket.repository.InvoiceRepository;

@Service
@Transactional
public class InvoiceService {
	@Autowired
	InvoiceRepository invoiceRepository;
	
	public Invoice createInvoice(Invoice invoice) {
		return invoiceRepository.save(invoice);
	}
	
	public List<Invoice> getInvoices(){
		return (List <Invoice>) invoiceRepository.findAll();
	}
	
	public Invoice updateInvoice(Invoice invoice) {	        
        return invoiceRepository.save(invoice);
    }

}
