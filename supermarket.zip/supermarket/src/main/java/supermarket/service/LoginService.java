package supermarket.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import supermarket.dto.Login;
import supermarket.dto.Product;
import supermarket.repository.LoginRepository;

@Service
@Transactional

public class LoginService {
	@Autowired
	LoginRepository loginRepository;
	
	public Login createLogin(Login login) {
		return loginRepository.save(login);
	}
	
	public List<Login> getLogins() {	        
        return (List<Login>) loginRepository.findAll();
	}
	
	public Login updateLogin(Login login) {
		return loginRepository.save(login);
	}
		
	
}
