package supermarket.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import supermarket.dto.Product;
import supermarket.repository.ProductRepository;

@Service
@Transactional
public class ProductService {
	@Autowired
    ProductRepository productRepository;

    public Product createProduct(Product product) {	       
    	return productRepository.save(product);
    }

    public List<Product> getProducts() {	        
        return (List<Product>) productRepository.findAll();
    }

    public Product updateProduct(Product product) {	        
        return productRepository.save(product);
    }

 }
