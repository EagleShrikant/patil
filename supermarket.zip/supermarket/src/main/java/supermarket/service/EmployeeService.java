package supermarket.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import supermarket.dto.Employee;
import supermarket.dto.Login;
import supermarket.repository.EmployeeRepository;

@Service
@Transactional
public class EmployeeService  {

	 	@Autowired
	    EmployeeRepository employeeRepository;
	 	
	 	@Autowired
	 	LoginService loginService;

	    public Employee createEmployee(Employee employee) {	       
	    	 Employee emp = employeeRepository.save(employee);
	    	 Login login = new Login();
	    	 login.setEmployee(emp);
	    	 loginService.createLogin(login);
	    	 return emp;
	    }

	    public List<Employee> getEmployees() {	        
	        return (List<Employee>) employeeRepository.findAll();
	    }

	
	    public Employee updateEmployee(Employee employee) {	        
	        return employeeRepository.save(employee);
	    }

}
