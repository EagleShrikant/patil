package supermarket.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import supermarket.dto.InvoiceDetails;
import supermarket.repository.InvoiceDetailsRepository;

@Service
@Transactional
public class InvoiceDetailsService {
	
		@Autowired
		InvoiceDetailsRepository invoiceDetailsRepository;
		
		public void createInvoiceDetails(InvoiceDetails invoiceDetails) {
			invoiceDetailsRepository.save(invoiceDetails);
		}
		
		public List<InvoiceDetails> getInvoiceDetails(){
			return (List <InvoiceDetails>) invoiceDetailsRepository.findAll();
		}
		
	    public InvoiceDetails update(InvoiceDetails invoiceDetails) {	        
	        return invoiceDetailsRepository.save(invoiceDetails);
	    }

}
