package supermarket.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Entity
@Setter
@Getter
@Table(name = "Product")
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Integer productNo;
	
	@Column(name = "productName")
	String productName;
	
	@Column(name = "qtyInStock")
	Integer qtyInStock;
	
	@Column(name = "qtyOnDemand")
	Integer qtyOnDemand;
	
	@Column(name = "QtyAlerts")
	Integer qtyAlerts;
	
	@Column(name = "pricePerUnit")
	Float pricePerUnit;
	
	@Column(name = "productVenderName")
	String productVenderName;
	
	@Column(name = "productVenderContactNo")
	Long productVenderContactNo;
	
	@Column(name = "productDiscount")
	Integer productDiscount;
	
	@Column(name = "productDescription")
	String productDescription;
	
	@Column(name = "isActive")
	Boolean isActive;

}
