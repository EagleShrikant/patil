package supermarket.dto;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Entity
@Setter
@Getter
@Table(name = "Employee")
public class Employee {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Integer empNo;
	
	@Column(name = "userName", unique=true)
	String userName;
	
	@Column(name = "empFName")
	String empFName;
	
	@Column(name = "empLName")
	String empLName;
	
	@Column(name = "empEmail")
	String empEmail;
	
	@Column(name = "empMobNo")
	Long empMobNo;
	
	@Column(name = "empDOB")
	Date empDOB;
	
	@Column(name = "empContry")
	String empContry;
	
	@Column(name = "empState")
	String empState;
	@Column(name = "empCity")
	String empCity;
	
	@Column(name = "empAddLine1")
	String empAddLine1;
	
	@Column(name = "empAddLine2")
	String empAddLine2;
	
	@Column(name = "isActive")
	Boolean isActive;
}
