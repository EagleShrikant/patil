package supermarket.dto;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Entity
@Setter
@Getter
@Table(name = "Invoice")
public class Invoice {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Integer invoiceNo;
	
	@Column(name = "customerMobNo")
	Long customerMobNo;
	
	@OneToMany(mappedBy = "invoice", cascade = CascadeType.ALL)
    private Set<InvoiceDetails> invoiceDetails;
	
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "empNo", referencedColumnName = "empNo")
    private Employee employee;
	
	@Column(name = "customerName")
	String customerName;
	
	@Column(name = "invoiceDate")
	Date invoiceDate;
	
}
