package supermarket.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Entity
@Setter
@Getter
@Table(name = "InvoiceDatails")
public class InvoiceDetails {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Integer IDNo;
	
	@ManyToOne
	@JoinColumn
	private Invoice invoice;
	
	@Column(name = "productNo")
	Integer productNo;
	
	@Column(name = "productName")
	String productName;
	
	@Column(name = "discount")
	Integer discount;
	
	@Column(name = "quentity")
	Integer quentity;
	
	@Column(name = "unitPrice")
	Float unitprice;
}
