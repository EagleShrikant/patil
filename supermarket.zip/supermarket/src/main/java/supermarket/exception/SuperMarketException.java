package supermarket.exception;


import org.springframework.http.HttpStatus;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SuperMarketException extends Exception{

	private static final long serialVersionUID = 1L;
	
	private HttpStatus statusCode;
	
	public SuperMarketException(String statusMessage) {
		super(statusMessage);
	}
	
	public SuperMarketException(String statusMessage, Exception e) {
		super(statusMessage,e);
	}
	
	public SuperMarketException(HttpStatus statusCode, String statusMessage) {
		super(statusMessage);
		this.statusCode = statusCode;
	}
	
	public SuperMarketException(HttpStatus statusCode, String statusMessage, Exception e ) {
		super(statusMessage,e);
		this.statusCode = statusCode;
	}
}
