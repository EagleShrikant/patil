export const environment = {
  production: true,

  employeeURL : 'http://localhost:8082/v1/supermarket/employee',
  productURL : 'http://localhost:8082/v1/supermarket/product',
  loginURL : 'http://localhost:8082/v1/supermarket/login',
};
