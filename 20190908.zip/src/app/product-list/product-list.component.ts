import { Component, OnInit, ViewChild } from '@angular/core';
import { Product } from '../dto/Product';
import { Router } from '@angular/router';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { DataSharingService } from '../services/data-sharing.service';
import { ProductservicesService } from '../services/productservices.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  productNameFilter: String;
  productNoFilter: String;
  filterValue: String[];

  productList: Product[];

  displayedColumns: string[] = ['productNo', 'productName','productDiscount', 'pricePerUnit', 'productDescription', 'isActive', 'onEdit'];
  dataSource: any;

  constructor(private router: Router, private productService: ProductservicesService, private dataService: DataSharingService) {
    this.getProductData()
    this.filterValue = [this.productNameFilter, this.productNoFilter];
  }


  ngOnInit() {
  }
  setProductNo(filterValue: string) {
    this.productNoFilter = filterValue;
    this.applyFilter();
  }
  setProductName(filterValue: string) {
    this.productNameFilter = filterValue;
    this.applyFilter();
  }

  applyFilter() {
    this.dataSource.filterPredicate =
      (data: any, filter: string[]) => {

        return (data.productName.toLowerCase().indexOf(filter[0]) != -1) &&
          (data.productNo.toString().toLowerCase().indexOf(filter[1]) != -1);
      }
    if (this.productNameFilter !== undefined)
      this.filterValue[0] = this.productNameFilter.trim().toLowerCase();
    if (this.productNoFilter !== undefined)
      this.filterValue[2] = this.productNoFilter.trim().toLowerCase();
    console.log(this.filterValue);

    this.dataSource.filter = this.filterValue;
  }

  resetFilters() {
    this.productNoFilter = '';
    this.productNameFilter = '';
    this.applyFilter();
  }


  getProductData(): void {
    this.productService.getProducts()
      .subscribe(unbilledData => {
        this.productList = unbilledData
        this.productList.forEach(product => {
          this.dataSource = new MatTableDataSource<Product>(this.productList);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;

        });
      }
      );
  }

  editProduct(i) {
    this.dataService.productForEdit = this.productList[i];
    console.log("Edit " + this.dataService.productForEdit);
  }

}