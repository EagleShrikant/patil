import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-print-page',
  templateUrl: './print-page.component.html',
  styleUrls: ['./print-page.component.css']
})
export class PrintPageComponent implements OnInit {

  constructor(private router: Router) {
     
   }

  ngOnInit() {
   
  }

  printInvoice(){
  console.log('Printing Page');
  window.print();
  this.router.navigateByUrl('invoice');
  }
}
