import { Component, OnInit, ViewChild } from '@angular/core';
import { Employee } from '../dto/Employee';
import { Router } from '@angular/router';
import { EmployeeServiceService } from '../services/employee-service.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { DataSharingService } from '../services/data-sharing.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  employeeFNameFilter: String = '';
  employeeLNameFilter: String = '';
  empCityFilter: String = '';
  empNumberFilter: String = '';
  filterValue: String[];
  employeeList: Employee[];
  displayedColumns: string[] = ['empNo', 'empFName', 'empLName','empCity','empEmail' , 'isActive','onEdit'];
  dataSource: any;

  constructor(private router: Router, private empService: EmployeeServiceService, private dataService: DataSharingService) {
    this.getEmployeeData();
    this.filterValue = [this.employeeFNameFilter,this.employeeLNameFilter,this.empCityFilter,this.empNumberFilter];
  }

  ngOnInit() {
  }

  setEmployeeNumber(filterValue: string) {
    this.empNumberFilter = filterValue;
    this.applyFilter();
  }
  setEmpCity(filterValue: string) {
    this.empCityFilter = filterValue;
    this.applyFilter();
  }
  setEmployeeFName(filterValue: string) {
    this.employeeFNameFilter = filterValue;
    this.applyFilter();
  }

  setEmployeeLName(filterValue: string) {
    this.employeeLNameFilter = filterValue;
    this.applyFilter();
  }

  applyFilter() {

    if (this.employeeFNameFilter !== undefined)
      this.filterValue[0] = this.employeeFNameFilter.trim().toLowerCase();
    if (this.employeeLNameFilter !== undefined)
      this.filterValue[1] = this.employeeLNameFilter.trim().toLowerCase();
    if (this.empCityFilter !== undefined)
      this.filterValue[2] = this.empCityFilter.trim().toLowerCase();
    if (this.empNumberFilter !== undefined)
      this.filterValue[3] = this.empNumberFilter.trim().toLowerCase();

    this.dataSource.filterPredicate =
      (data: any, filter: string[]) => {
        return (data.empFName.toLowerCase().indexOf(filter[0]) != -1) &&
          (data.empLName.toLowerCase().indexOf(filter[1]) != -1) &&
          (data.empCity.toLowerCase().indexOf(filter[2]) != -1) &&
          (data.empNo.toString().toLowerCase().indexOf(filter[3]) != -1);

      }
    this.dataSource.filter = this.filterValue;
  }

  resetFilters() {
    this.empNumberFilter = '';
    this.empCityFilter = '';
    this.employeeFNameFilter = '';
    this.employeeLNameFilter = '';
    this.applyFilter();
  }

  getEmployeeData(): void {
    this.empService.getEmployees()
      .subscribe(employeeData => {
        this.employeeList = employeeData
        this.employeeList.forEach(employee => {
          this.dataSource = new MatTableDataSource<Employee>(this.employeeList);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;

        });
      }
      );
  }

  editEmployee(i) {
    this.dataService.employeeForEdit = this.employeeList[i];
    //console.log("Edit " + i + "" + this.dataService.employeeForEdit);
  }

}
