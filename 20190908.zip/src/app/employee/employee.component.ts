import { Component, OnInit } from '@angular/core';
import { Employee } from '../dto/Employee';
import { Router } from '@angular/router';
import { EmployeeServiceService } from '../services/employee-service.service';
import { DataSharingService } from '../services/data-sharing.service';
import { LoginServiceService } from '../services/login-service.service';
import { Login } from '../dto/Login';


@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  employee: Employee;
  isNewEntry: Boolean = false;
  response: any;
  login : Login;
  constructor(private router: Router, private empService: EmployeeServiceService, private loginService: LoginServiceService,private dataService: DataSharingService) {
    this.employee = dataService.employeeForEdit;

    if (this.employee === null || this.employee === undefined) {
      this.employee = new Employee();
    }
    if (null != this.employee && null != this.employee.empDOB) {
      let date = new Date(this.employee.empDOB);
      this.employee.empDOB = date;
    }
    console.log(this.employee);
    if (
      (this.employee !== undefined) && (
        this.employee.empNo === undefined)) {
      this.isNewEntry = true;
    } else {
      this.isNewEntry = false;
    }
  }

  ngOnInit() {
  }

  saveEmployee(employee: Employee) {
    if (this.isNewEntry) {
      this.empService.addEmployee(employee).
        subscribe(response => this.response = response);       
      this.dataService.employeeForEdit = undefined;
      this.router.navigateByUrl('employees');
    } else {
      this.empService.updateEmployee(employee).
        subscribe(response => {
          this.response = response;
          this.dataService.employeeForEdit = undefined;
          this.router.navigateByUrl('employees');
        }
        );
    }
  }

  isEmployeeActiveUpdate() {
    if ((this.employee.isActive !== undefined &&
      this.employee.isActive === true)
    ) {
      this.employee.isActive = false;
    } else {
      this.employee.isActive = true;
    }
  }

  cancelSave() {
    this.dataService.employeeForEdit = undefined;
  }

}
