import { Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ProductservicesService } from '../services/productservices.service';
import { DataSharingService } from '../services/data-sharing.service';
import { Product } from '../dto/Product';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { InvoiceDetails } from '../dto/InvoiceDetails';
import { Invoice } from '../dto/Invoice';
import { InvoiceServiceService } from '../services/invoice-service.service';

@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.css']
})
export class InvoiceComponent implements OnInit {
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  displayedColumns: string[] = ['productNo', 'productName', 'unitPrice', 'quentity', 'discount', 'price', 'onRemove'];
  displayedPColumns: string[] = ['productNo', 'productName', 'pricePerUnit', 'discount', 'onAdd'];
  dataSource: any;
  invoiceDetailsArray: InvoiceDetails[] = new Array;
  invoiceDetails: InvoiceDetails;
  dataProductSource: any;
  productList: Product[];
  today: Date;
  saveInvoiceItem : Invoice;
  constructor(private router: Router, private productService: ProductservicesService, 
    private dataService: DataSharingService, private invoiceService : InvoiceServiceService) {
    this.getProductData();
    this.dataSource = new Array;
    console.log(this.dataProductSource);
    this.today = new Date();
  }

  ngOnInit() {
  }

  applyFilter(filterValue: string) {
    this.dataProductSource.filter = filterValue;
  }
  getProductData(): void {
    this.productService.getProducts()
      .subscribe(productList => {
        console.log(productList);
        this.productList = productList;
        this.productList.forEach(product => {
          this.dataProductSource = new MatTableDataSource<Product>(this.productList);
          this.dataProductSource.paginator = this.paginator;
          this.dataProductSource.sort = this.sort;

        });
      }
      );
    console.log(this.dataProductSource);
  }

  onAdd(i): void {
    console.log(this.productList[i]);
    this.invoiceDetails = new InvoiceDetails();
    this.invoiceDetails.productName = this.productList[i].productName;
    this.invoiceDetails.productNo = this.productList[i].productNo;
    this.invoiceDetails.unitPrice = this.productList[i].pricePerUnit;
    this.invoiceDetails.discount = this.productList[i].productDiscount;
    this.invoiceDetails.quentity = 0;
    this.invoiceDetailsArray.push(this.invoiceDetails);

    console.log(this.invoiceDetailsArray);

    this.invoiceDetailsArray.forEach(invoiceDetail => {
      this.dataSource = new MatTableDataSource<InvoiceDetails>(this.invoiceDetailsArray);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;

    });    
  }

  saveInvoice(){
    this.saveInvoiceItem = new Invoice();
    this.saveInvoiceItem.customerNo = 0;
    this.saveInvoiceItem.customerName = '';
    //this.saveInvoiceItem.employee = '';
    this.saveInvoiceItem.invoiceDate = this.today;
    this.saveInvoiceItem.invoiceDetails = this.invoiceDetailsArray;    
    this.invoiceService.createInvoice(this.saveInvoiceItem);
  }

  getTotalPrice() {
    return this.invoiceDetailsArray.map(element =>
      ((element.unitPrice.valueOf() * element.quentity.valueOf()) - (element.unitPrice.valueOf() * element.quentity.valueOf() * element.discount.valueOf() / 100))).reduce((acc, value) => acc + value, 0);
  }

  getQuentityTotal() {
    return this.invoiceDetailsArray.map(element =>
      (element.quentity.valueOf() * 1.0)).reduce((acc, value) => acc + value, 0);
  }
}
