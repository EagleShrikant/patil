import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HttpClientModule} from '@angular/common/http';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatNativeDateModule} from '@angular/material/core';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {DemoMaterialModule} from './../material-module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { routing } from './app.routing';
import { LoginComponent } from './login/login.component';
import { MenuComponent } from './menu/menu.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { ProductComponent } from './product/product.component';
import { ProductListComponent } from './product-list/product-list.component';
import { BillComponent } from './bill/bill.component';
import { InvoiceComponent } from './invoice/invoice.component';
import { PrintPageComponent } from './print-page/print-page.component';
import { LoginListComponent } from './login-list/login-list.component';
import { EditLoginComponent } from './edit-login/edit-login.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    LoginComponent,
    MenuComponent,
    HeaderComponent,
    FooterComponent,
    EmployeeComponent,
    EmployeeListComponent,
    ProductComponent,
    ProductListComponent,
    BillComponent,
    InvoiceComponent,
    PrintPageComponent,
    LoginListComponent,
    EditLoginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    DemoMaterialModule,
    MatNativeDateModule,
    ReactiveFormsModule,
    routing,
  ],
  providers: [],
  bootstrap: [AppComponent]
})

export class AppModule { }
