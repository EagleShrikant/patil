import { Component, OnInit } from '@angular/core';
import { Product } from '../dto/Product';
import { Router } from '@angular/router';
import { ProductservicesService } from '../services/productservices.service';
import { DataSharingService } from '../services/data-sharing.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  product: Product;
  isNewEntry: Boolean = false;
  response: any;
  constructor(private router: Router, private productService: ProductservicesService, private dataService: DataSharingService) {
    this.product = dataService.productForEdit;

    if (this.product === null || this.product === undefined) {
      this.product = new Product();
    }
    console.log(this.product);
    if (
      (this.product !== undefined) && (
        this.product.productNo === undefined)) {
      this.isNewEntry = true;
    } else {
      this.isNewEntry = false;
    }
  }

  ngOnInit() {
  }

  saveProduct(product: Product) {
    if (this.isNewEntry) {
      this.productService.addProduct(product).
        subscribe(response => this.response = response);
      this.dataService.productForEdit = undefined;
      this.router.navigateByUrl('products');
    } else {
      this.productService.updateProduct(product).
        subscribe(response => {
          this.response = response;
          this.dataService.productForEdit = undefined;
          this.router.navigateByUrl('products');
        });
    }
  }

  isProductActiveUpdate() {
    if ((this.product.isActive !== undefined &&
      this.product.isActive === true)
    ) {
      this.product.isActive = false;
    } else {
      this.product.isActive = true;
    }
  }

  cancelSave() {
    this.dataService.productForEdit = undefined;
  }

}
