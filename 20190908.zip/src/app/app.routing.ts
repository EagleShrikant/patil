import { Routes, RouterModule } from "@angular/router";
import { AppComponent } from './app.component';
import {DashboardComponent} from '../app/dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { ProductComponent } from './product/product.component';
import { ProductListComponent } from './product-list/product-list.component';
import { InvoiceComponent } from './invoice/invoice.component';
import { PrintPageComponent } from './print-page/print-page.component';
import { LoginListComponent } from './login-list/login-list.component';
import { EditLoginComponent } from './edit-login/edit-login.component';

const appRoutes: Routes = [
  {
    path: "",
    redirectTo: "login",
    pathMatch: "full"
  },
  {
    path: "angular",
    redirectTo: "login",
    pathMatch: "full"
  },
  {
    path: "login",
    component: LoginComponent
  },
  {
    path: "employee",
    component: EmployeeComponent
  },
  {
    path: "employees",
    component: EmployeeListComponent
  },
  {
    path: "product",
    component: ProductComponent
  },
  {
    path: "products",
    component: ProductListComponent
  },
  {
    path: "invoice",
    component: InvoiceComponent
  },
  {
    path: "dashboard",
    component: DashboardComponent
  },
  {
    path: "access",
    component: LoginListComponent
  },
  {
    path: "editlogin",
    component: EditLoginComponent
  },
  {
    path: "printpage",
    component: PrintPageComponent
  },
  // otherwise redirect to home
  { path: "**", redirectTo: "/" }
];

export const routing = RouterModule.forRoot(appRoutes);