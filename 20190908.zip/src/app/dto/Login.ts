import { Employee } from './Employee';

export class Login {
    constructor() { }
    loginNo: Number;
    employee: Employee;
    password: String;
    userRole: String;
    isActive: Boolean;
}