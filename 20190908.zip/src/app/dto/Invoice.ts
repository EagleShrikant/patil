import { Employee } from './Employee';
import { InvoiceDetails } from './InvoiceDetails';

export class Invoice {
    constructor() { }
    invoiceNo: Number;
    employee: Employee;
    invoiceDetails : InvoiceDetails[];
    customerNo: Number;
    customerName: String;
    invoiceDate: Date;
}