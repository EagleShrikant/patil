import { Invoice } from './Invoice';

export class InvoiceDetails {
    constructor() { }
    IDNo: Number;
    invoice: Invoice;
    productNo: Number;
    productName: String;
    quentity: Number;
    discount:Number;
    unitPrice: Number;
}