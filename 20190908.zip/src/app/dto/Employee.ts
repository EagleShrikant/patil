export class Employee{
    constructor(){}
    empNo : Number;
    userName : String;  
    empFName : String;
    empLName : String;
    empEmail : String;
    empMobNo : Number;
    empDOB : Date;
    empContry : String;
    empState : String;
    empCity: String;
    empAddLine1 : String;
    empAddLine2 : String;
    isActive : Boolean;
}