export class Product {
    constructor() { }
    productNo: Number;
    qtyInStock: Number;
    qtyOnDemand: Number;
    qtyAlerts: Number;
    pricePerUnit: Number;
    productName: String;
    productVenderName: String;
    productVenderContactNo: Number;
    productDiscount: Number;
    productDescription: String;
    isActive: Boolean;
}