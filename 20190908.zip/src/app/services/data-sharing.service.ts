import { Injectable } from '@angular/core';
import { Employee } from '../dto/Employee';
import { Product } from '../dto/Product';
import { Login } from '../dto/Login';

@Injectable({
  providedIn: 'root'
})
export class DataSharingService {

  constructor() { }
  employeeForEdit : Employee;
  productForEdit : Product;
  loginForEdit : Login;

  userName : String;
  userRole : String;
  empNo : Number;
}
