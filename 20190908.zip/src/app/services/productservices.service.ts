import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { Product } from '../dto/Product';
import { environment } from '../../environments/environment';
import { catchError, map, tap } from 'rxjs/operators';
import { MessageService } from './message.service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class ProductservicesService {
  private productURL = environment.productURL;
  constructor(private http: HttpClient, private messageService: MessageService, ) { }

  /** GET heroes from the product */
  getProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(this.productURL)
      .pipe(
        tap(_ => this.log('fetched products')),
        catchError(this.handleError('getSummary', []))
      );
  }
  updateProduct(product: Product) {
    return this.http.put<Product>(this.productURL, product)
      .pipe(
        tap(_ => this.log('Saved products')),
        catchError(this.handleError('getProduct', []))
      );
  }
  addProduct(product: Product) {
    return this.http.post<Product>(this.productURL, product, httpOptions)
      .pipe(
        tap(_ => this.log('Add products')),
        catchError(this.handleError('getProduct', []))
      );
  }

  /**
 * Handle Http operation that failed.
 * Let the app continue.
 * @param operation - name of the operation that failed
 * @param result - optional value to return as the observable result
 */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

  /** Log a HeroService message with the MessageService */
  private log(message: string) {
    this.messageService.add(`HeroService: ${message}`);
  }

}