import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { Employee } from '../dto/Employee';
import { environment } from '../../environments/environment';
import { catchError, map, tap } from 'rxjs/operators';
import { MessageService } from './message.service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })

};

@Injectable({
  providedIn: 'root'
})
export class EmployeeServiceService {


  private employeeURL = environment.employeeURL;
  constructor(private http: HttpClient, private messageService: MessageService, ) { }

  /** GET heroes from the employees */
  getEmployees(): Observable<Employee[]> {
    return this.http.get<Employee[]>(this.employeeURL)
      .pipe(
        tap(_ => this.log('fetched employees')),
        catchError(this.handleError('getEmployee', []))
      );
  }

  updateEmployee(employee: Employee) {
    return this.http.put<Employee>(this.employeeURL, employee)
      .pipe(
        tap(_ => this.log('Saved employees')),
        catchError(this.handleError('getEmployee', []))
      );
  }
  addEmployee(employee: Employee) {
    return this.http.post<Employee>(this.employeeURL, employee, httpOptions)
      .pipe(
        tap(_ => this.log('Add employees')),
        catchError(this.handleError('getEmployee', []))
      );
  }

  /**
 * Handle Http operation that failed.
 * Let the app continue.
 * @param operation - name of the operation that failed
 * @param result - optional value to return as the observable result
 */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }

  /** Log a HeroService message with the MessageService */
  private log(message: string) {
    this.messageService.add(`HeroService: ${message}`);
  }

}
