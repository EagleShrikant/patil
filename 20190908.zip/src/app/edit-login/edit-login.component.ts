import { Component, OnInit } from '@angular/core';
import { Login } from '../dto/Login';
import { LoginServiceService } from '../services/login-service.service';
import { Router } from '@angular/router';
import { DataSharingService } from '../services/data-sharing.service';

@Component({
  selector: 'app-edit-login',
  templateUrl: './edit-login.component.html',
  styleUrls: ['./edit-login.component.css']
})
export class EditLoginComponent implements OnInit {
  login: Login;
  isNewEntry: Boolean = false;
  response: any;
  constructor(private router: Router, private loginService: LoginServiceService, private dataService: DataSharingService) {
    this.login = dataService.loginForEdit;

    if (this.login === null || this.login === undefined) {
      this.login = new Login();
    }
    console.log(this.login);
    if (
      (this.login !== undefined) && (
        this.login.loginNo === undefined)) {
      this.isNewEntry = true;
    } else {
      this.isNewEntry = false;
    }
  }

  ngOnInit() {
  }

  saveLogin(login: Login) {
    if (this.isNewEntry) {
      this.loginService.addLogin(login).
        subscribe(response => this.response = response);
      this.dataService.productForEdit = undefined;
      this.router.navigateByUrl('access');
    } else {
      this.loginService.updateLogin(login).
        subscribe(response => {
          this.response = response;
          this.dataService.productForEdit = undefined;
          this.router.navigateByUrl('access');
        });
    }
  }

  isLoginActiveUpdate() {
    if ((this.login.isActive !== undefined &&
      this.login.isActive === true)
    ) {
      this.login.isActive = false;
    } else {
      this.login.isActive = true;
    }
  }

  cancelSave() {
    this.dataService.loginForEdit = undefined;
  }

}
