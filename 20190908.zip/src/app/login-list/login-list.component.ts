import { Component, OnInit, ViewChild } from '@angular/core';
import { Login } from '../dto/Login';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { Router } from '@angular/router';
import { LoginServiceService } from '../services/login-service.service';
import { DataSharingService } from '../services/data-sharing.service';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-login-list',
  templateUrl: './login-list.component.html',
  styleUrls: ['./login-list.component.css']
})
export class LoginListComponent implements OnInit {
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  userNameFilter: String;
  employeeNoFilter: String;
  filterValue: String[];

  loginList: Login[];

  displayedColumns: string[] = ['loginNo', 'empNo','userName', 'userRole', 'isActive', 'onEdit'];
  dataSource: any;
  constructor(private router: Router, private loginService: LoginServiceService, private dataService: DataSharingService) { 
    this.getLoginData()
    this.filterValue = [this.userNameFilter, this.employeeNoFilter];
  }

  ngOnInit() {
  }

  setEmployeeNo(filterValue: string) {
    this.employeeNoFilter = filterValue;
    this.applyFilter();
  }
  setUserName(filterValue: string) {
    this.userNameFilter = filterValue;
    this.applyFilter();
  }

  applyFilter() {
    this.dataSource.filterPredicate =
      (data: any, filter: string[]) => {

        return (data.productName.toLowerCase().indexOf(filter[0]) != -1) &&
          (data.productNo.toString().toLowerCase().indexOf(filter[1]) != -1);
      }
    if (this.userNameFilter !== undefined)
      this.filterValue[0] = this.userNameFilter.trim().toLowerCase();
    if (this.employeeNoFilter !== undefined)
      this.filterValue[2] = this.employeeNoFilter.trim().toLowerCase();
    console.log(this.filterValue);

    this.dataSource.filter = this.filterValue;
  }

  resetFilters() {
    this.employeeNoFilter = '';
    this.userNameFilter = '';
    this.applyFilter();
  }


  getLoginData(): void {
    this.loginService.getLogins()
      .subscribe(unbilledData => {
        this.loginList = unbilledData
        this.loginList.forEach(product => {
          this.dataSource = new MatTableDataSource<Login>(this.loginList);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;

        });
      }
      );
  }

  editLogin(i) {
    this.dataService.loginForEdit = this.loginList[i];
    console.log("Edit " + this.dataService.loginForEdit);
  }

}
