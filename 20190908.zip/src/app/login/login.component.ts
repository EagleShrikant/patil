import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginServiceService } from '../services/login-service.service';
import { DataSharingService } from '../services/data-sharing.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  title = 'SP Supermarket Billing Manegment';
  username: String;
  password: String;
  pwdErrorMsg: boolean = false;
  constructor(private router: Router, private loginService : LoginServiceService, private dataService: DataSharingService) {
    console.log("Inside Constructure");
  }


  ngOnInit() {

    console.log("NG Init");

  }


  verifyUser() {

    console.log(this.username);
    console.log(this.password);
    if (this.username == "a" && this.password == "a") {
      console.log("Welcome");
      this.dataService.userName = this.username;
      this.dataService.userRole = "Admin";
      this.router.navigateByUrl('dashboard');
      this.pwdErrorMsg = false;
    } else {
      console.log("Invalid Password");
      this.pwdErrorMsg = true;
    }
  }
  
}
